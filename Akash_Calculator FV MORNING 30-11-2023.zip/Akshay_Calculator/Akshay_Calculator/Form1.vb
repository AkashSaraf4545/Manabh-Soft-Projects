﻿Public Class display
    Dim assign_input As Double = 0
    Dim operation As String
    Dim found_expression As Boolean = False
    Dim Firstnum As String
    Dim memory As Double
    Dim inputText As String
    Private lastOperator As Char = " " ' Initialize with a space or any default value


    Private Sub ADD_Sub_Button(sender As Object, e As EventArgs) Handles PLUS_MINUS_Button.Click
        If (TextDisplay.Text.Contains("-")) Then
            TextDisplay.Text = TextDisplay.Text.Remove(0, 1)

        Else

            TextDisplay.Text = "-" + TextDisplay.Text
        End If
    End Sub

    Private Sub Square_Button1(sender As Object, e As EventArgs) Handles Square_Button.Click
        Dim a As Double

        a = TextDisplay.Text * TextDisplay.Text
        TextDisplay.Text = System.Convert.ToString(a)


    End Sub


    Private Sub Sqrt_Button(sender As Object, e As EventArgs) Handles Button43.Click
        Dim a As Double
        a = Math.Sqrt(TextDisplay.Text)
        TextDisplay.Text = System.Convert.ToString(a)
    End Sub

    Private Sub Num_Click(sender As Object, e As EventArgs) Handles MyBase.Click, Button8.Click, Button5.Click, Button46.Click, Button44.Click, Button42.Click, Button41.Click, Button40.Click, Button38.Click, Button25.Click, Button24.Click, Button12.Click

        Dim b As Button = sender

        If ((TextDisplay.Text = "0") Or (found_expression)) Then
            TextDisplay.Clear()
            TextDisplay.Text = b.Text
            found_expression = False

        ElseIf (b.Text = ".") Then

            If (Not TextDisplay.Text.Contains(".")) Then
                TextDisplay.Text = TextDisplay.Text + b.Text
            End If

        Else

            TextDisplay.Text = TextDisplay.Text + b.Text

        End If

    End Sub
    Private Sub Arthematic_Ope3rator_Click(sender As Object, e As EventArgs) Handles Sub_Button.Click, Mul_Button.Click, Div_Button.Click, Add_Button.Click
        Dim b As Button = sender
        If (assign_input <> 0) Then
            Equal_Button.PerformClick()
            found_expression = True
            operation = b.Text
            Equ_Label.Text = assign_input & "  " & operation

        Else
            operation = b.Text
            assign_input = Double.Parse(TextDisplay.Text)
            found_expression = True
            Equ_Label.Text = assign_input & "  " & operation

        End If
    End Sub

    Private Sub Equal_Button_Click(sender As Object, e As EventArgs) Handles Equal_Button.Click

        Equ_Label.Text = ""
        Select Case operation

            Case "+"

                TextDisplay.Text = assign_input + TextDisplay.Text

            Case "-"

                TextDisplay.Text = (assign_input - Double.Parse(TextDisplay.Text)).ToString()

            Case "x"

                TextDisplay.Text = (assign_input * Double.Parse(TextDisplay.Text)).ToString()

            Case "/"

                TextDisplay.Text = (assign_input / Double.Parse(TextDisplay.Text)).ToString()

        End Select

        assign_input = Double.Parse(TextDisplay.Text)

        operation = " "

    End Sub

    Private Sub Perc_Button(sender As Object, e As EventArgs) Handles Percent_Button.Click
        Dim a As Double
        a = Convert.ToDouble(TextDisplay.Text) * Convert.ToDouble(TextDisplay.Text) / Convert.ToDouble(100)
        TextDisplay.Text = System.Convert.ToString(a)
    End Sub

    Private Sub Ix_Button_Click(sender As Object, e As EventArgs) Handles Ix_Button.Click
        Dim a As Double
        a = Convert.ToDouble(1.0 / Convert.ToDouble(TextDisplay.Text))
        TextDisplay.Text = System.Convert.ToString(a)
    End Sub

    Private Sub Back_Button_Click_1(sender As Object, e As EventArgs) Handles Back_Button.Click
        If TextDisplay.Text.Length > 0 Then
            TextDisplay.Text = Mid(TextDisplay.Text, 1, Len(TextDisplay.Text) - 1)
        End If
    End Sub



    Private Sub Clear_Entry_Button_Click(sender As Object, e As EventArgs) Handles Clear_Entry_Button.Click
        TextDisplay.Text = "0"
        Equ_Label.Text = ""
        assign_input = 0
        TextDisplay.Focus()

    End Sub

    Private Sub Clear_Button_Click(sender As Object, e As EventArgs) Handles Clear_Button.Click
        TextDisplay.Text = "0"
        Equ_Label.Text = ""
        assign_input = 0
        TextDisplay.Focus()

    End Sub
    Private Sub Back_Button_Click(sender As Object, e As EventArgs)
        If (TextDisplay.Text.Length > 0) Then

            TextDisplay.Text = TextDisplay.Text.Remove(TextDisplay.Text.Length - 1, 1)

        End If
        If (TextDisplay.Text = "") Then
            TextDisplay.Text = "0"
        End If
    End Sub


    Private Sub isFirst()
        If found_expression = False Then
            Firstnum = CType(txtDisplay.Text, Decimal)
            found_expression = True
            txtDisplay.Text = "0"
        End If
    End Sub

    Private Sub Panel3_Paint(sender As Object, e As PaintEventArgs) Handles Panel3.Paint
        'TextDisplay.Focus()
    End Sub

    Private Sub MemSave_Click(sender As Object, e As EventArgs) Handles MemSave.Click
        If TextDisplay.Text <> 0 Then
            memory = TextDisplay.Text
        End If

    End Sub

    Private Sub MemRecollect_Click(sender As Object, e As EventArgs) Handles MemRecollect.Click
        TextDisplay.Text += memory
    End Sub



    Private Sub TextDisplay_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextDisplay.KeyPress




        '  QOL FUNCTIONALITIES
        If e.KeyChar = Convert.ToChar(Keys.Back) Then
            If TextDisplay.Text.Length > 0 Then
                TextDisplay.Text = Mid(TextDisplay.Text, 1, Len(TextDisplay.Text) - 1)
                TextDisplay.Select(TextDisplay.Text.Length, 0)
            End If
            If TextDisplay.Text.Length = 0 Then
                TextDisplay.Text = "0"
            End If
        End If

        If e.KeyChar = Convert.ToChar(Keys.Escape) Then
            TextDisplay.Text = "0"
            TextDisplay.Select(TextDisplay.Text.Length, 0)
        End If





        If TextDisplay.Text = "0" Then
            found_expression = True
        End If
        If Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57 Then
            e.Handled = True
        End If

        ' Check for numeric keys or decimal point
        If Char.IsDigit(e.KeyChar) OrElse e.KeyChar = "." Then
            If found_expression Then
                TextDisplay.Clear()
                found_expression = False
            End If
            ' Append the pressed key to the textbox
            TextDisplay.Text &= e.KeyChar.ToString()
            e.Handled = True
            TextDisplay.Select(TextDisplay.Text.Length, 0)



            '====================================================================================================================================================
        ElseIf e.KeyChar = "+" OrElse e.KeyChar = "-" OrElse e.KeyChar = "*" OrElse e.KeyChar = "/" Then
            found_expression = True ' Set the flag for a new number entry
            ' Handle arithmetic operator key presses
            HandleArithmeticOperatorKeyPress(e.KeyChar)
            e.Handled = True
            TextDisplay.Select(TextDisplay.Text.Length, 0)
            '====================================================================================================================================================


        ElseIf e.KeyChar = Convert.ToChar(Keys.Enter) Then
            ' Handle the Enter key press to calculate the result
            PerformCalculation()
            e.Handled = True
            TextDisplay.Select(TextDisplay.Text.Length, 0)
        End If
    End Sub

    ' Function to handle arithmetic operator key presses
    Private Sub HandleArithmeticOperatorKeyPress(keyChar As Char)
        If assign_input > 0 Then
            PerformCalculation()
        End If
        inputText = TextDisplay.Text.Trim()
        If Not String.IsNullOrEmpty(inputText) Then
            ' If there's an ongoing calculation, do not perform it yet
            If assign_input <> 0 AndAlso found_expression Then
                ' Update the operation only if the key pressed is a valid operator
                If "+-*/".Contains(keyChar) Then
                    lastOperator = keyChar ' Update the last operator
                    Equ_Label.Text = assign_input & " " & lastOperator
                End If
            Else
                ' Update the assign_input and found_expression
                assign_input = CDbl(inputText)
                found_expression = False
                lastOperator = keyChar ' Update the last operator
                Equ_Label.Text = assign_input & " " & lastOperator
                TextDisplay.Clear()   'if i use this the multi operator click functionality goes
            End If
        End If
    End Sub

    ' Function to perform the calculation based on stored operation
    Private Sub PerformCalculation()
        '  Dim currentValue As Double = CDbl(TextDisplay.Text)
        Dim currentValue As Double = Val(TextDisplay.Text)
        Select Case lastOperator
            Case "+"
                assign_input += currentValue

            Case "-"
                assign_input -= currentValue
            Case "*"
                assign_input *= currentValue
            Case "/"
                If currentValue <> 0 Then
                    assign_input /= currentValue
                Else
                    MessageBox.Show("Cannot divide by zero.")
                End If
        End Select

        ' Update the display with the result
        TextDisplay.Text = assign_input.ToString()
        Equ_Label.Text = ""
        found_expression = True
    End Sub

    Private Sub TextDisplay_MouseClick(sender As Object, e As MouseEventArgs) Handles TextDisplay.MouseClick

    End Sub
End Class







