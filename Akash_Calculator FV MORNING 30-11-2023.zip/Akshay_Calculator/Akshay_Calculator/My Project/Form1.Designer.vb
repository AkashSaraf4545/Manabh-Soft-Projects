﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Equ_Label = New System.Windows.Forms.Label()
        Me.PLUS_MINUS_Button = New System.Windows.Forms.Button()
        Me.Back_Button = New System.Windows.Forms.Button()
        Me.Square_Button = New System.Windows.Forms.Button()
        Me.Ix_Button = New System.Windows.Forms.Button()
        Me.Percent_Button = New System.Windows.Forms.Button()
        Me.TextDisplay = New System.Windows.Forms.TextBox()
        Me.Equal_Button = New System.Windows.Forms.Button()
        Me.Button43 = New System.Windows.Forms.Button()
        Me.Add_Button = New System.Windows.Forms.Button()
        Me.Sub_Button = New System.Windows.Forms.Button()
        Me.Mul_Button = New System.Windows.Forms.Button()
        Me.Button25 = New System.Windows.Forms.Button()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Div_Button = New System.Windows.Forms.Button()
        Me.Button38 = New System.Windows.Forms.Button()
        Me.Button24 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button40 = New System.Windows.Forms.Button()
        Me.Button41 = New System.Windows.Forms.Button()
        Me.Button42 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button44 = New System.Windows.Forms.Button()
        Me.Button46 = New System.Windows.Forms.Button()
        Me.Clear_Button = New System.Windows.Forms.Button()
        Me.Clear_Entry_Button = New System.Windows.Forms.Button()
        Me.Panel3.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel3.Controls.Add(Me.Equ_Label)
        Me.Panel3.Controls.Add(Me.PLUS_MINUS_Button)
        Me.Panel3.Controls.Add(Me.Back_Button)
        Me.Panel3.Controls.Add(Me.Square_Button)
        Me.Panel3.Controls.Add(Me.Ix_Button)
        Me.Panel3.Controls.Add(Me.Percent_Button)
        Me.Panel3.Controls.Add(Me.TextDisplay)
        Me.Panel3.Controls.Add(Me.Equal_Button)
        Me.Panel3.Controls.Add(Me.Button43)
        Me.Panel3.Controls.Add(Me.Add_Button)
        Me.Panel3.Controls.Add(Me.Sub_Button)
        Me.Panel3.Controls.Add(Me.Mul_Button)
        Me.Panel3.Controls.Add(Me.Button25)
        Me.Panel3.Controls.Add(Me.Button12)
        Me.Panel3.Controls.Add(Me.Div_Button)
        Me.Panel3.Controls.Add(Me.Button38)
        Me.Panel3.Controls.Add(Me.Button24)
        Me.Panel3.Controls.Add(Me.Button8)
        Me.Panel3.Controls.Add(Me.Button40)
        Me.Panel3.Controls.Add(Me.Button41)
        Me.Panel3.Controls.Add(Me.Button42)
        Me.Panel3.Controls.Add(Me.Button5)
        Me.Panel3.Controls.Add(Me.Button44)
        Me.Panel3.Controls.Add(Me.Button46)
        Me.Panel3.Controls.Add(Me.Clear_Button)
        Me.Panel3.Controls.Add(Me.Clear_Entry_Button)
        Me.Panel3.Location = New System.Drawing.Point(271, 45)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(259, 360)
        Me.Panel3.TabIndex = 2
        '
        'Equ_Label
        '
        Me.Equ_Label.AutoSize = True
        Me.Equ_Label.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Equ_Label.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Equ_Label.Location = New System.Drawing.Point(16, 58)
        Me.Equ_Label.Name = "Equ_Label"
        Me.Equ_Label.Size = New System.Drawing.Size(0, 24)
        Me.Equ_Label.TabIndex = 3
        Me.Equ_Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PLUS_MINUS_Button
        '
        Me.PLUS_MINUS_Button.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PLUS_MINUS_Button.Location = New System.Drawing.Point(195, 316)
        Me.PLUS_MINUS_Button.Name = "PLUS_MINUS_Button"
        Me.PLUS_MINUS_Button.Size = New System.Drawing.Size(58, 36)
        Me.PLUS_MINUS_Button.TabIndex = 1
        Me.PLUS_MINUS_Button.Text = "±"
        Me.PLUS_MINUS_Button.UseVisualStyleBackColor = True
        '
        'Back_Button
        '
        Me.Back_Button.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Back_Button.Location = New System.Drawing.Point(195, 111)
        Me.Back_Button.Name = "Back_Button"
        Me.Back_Button.Size = New System.Drawing.Size(58, 36)
        Me.Back_Button.TabIndex = 1
        Me.Back_Button.Text = "DEL"
        Me.Back_Button.UseVisualStyleBackColor = True
        '
        'Square_Button
        '
        Me.Square_Button.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Square_Button.Location = New System.Drawing.Point(131, 150)
        Me.Square_Button.Name = "Square_Button"
        Me.Square_Button.Size = New System.Drawing.Size(58, 34)
        Me.Square_Button.TabIndex = 1
        Me.Square_Button.Text = "x^2"
        Me.Square_Button.UseVisualStyleBackColor = True
        '
        'Ix_Button
        '
        Me.Ix_Button.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Ix_Button.Location = New System.Drawing.Point(3, 150)
        Me.Ix_Button.Name = "Ix_Button"
        Me.Ix_Button.Size = New System.Drawing.Size(58, 34)
        Me.Ix_Button.TabIndex = 1
        Me.Ix_Button.Text = "1/x"
        Me.Ix_Button.UseVisualStyleBackColor = True
        '
        'Percent_Button
        '
        Me.Percent_Button.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Percent_Button.Location = New System.Drawing.Point(3, 111)
        Me.Percent_Button.Name = "Percent_Button"
        Me.Percent_Button.Size = New System.Drawing.Size(58, 36)
        Me.Percent_Button.TabIndex = 1
        Me.Percent_Button.Text = "%"
        Me.Percent_Button.UseVisualStyleBackColor = True
        '
        'TextDisplay
        '
        Me.TextDisplay.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextDisplay.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextDisplay.Location = New System.Drawing.Point(4, 37)
        Me.TextDisplay.Multiline = True
        Me.TextDisplay.Name = "TextDisplay"
        Me.TextDisplay.Size = New System.Drawing.Size(250, 68)
        Me.TextDisplay.TabIndex = 1
        Me.TextDisplay.Text = "0"
        Me.TextDisplay.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Equal_Button
        '
        Me.Equal_Button.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Equal_Button.Location = New System.Drawing.Point(131, 316)
        Me.Equal_Button.Name = "Equal_Button"
        Me.Equal_Button.Size = New System.Drawing.Size(58, 36)
        Me.Equal_Button.TabIndex = 1
        Me.Equal_Button.Text = "="
        Me.Equal_Button.UseVisualStyleBackColor = True
        '
        'Button43
        '
        Me.Button43.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button43.Location = New System.Drawing.Point(67, 150)
        Me.Button43.Name = "Button43"
        Me.Button43.Size = New System.Drawing.Size(58, 34)
        Me.Button43.TabIndex = 1
        Me.Button43.Text = "√x"
        Me.Button43.UseVisualStyleBackColor = True
        '
        'Add_Button
        '
        Me.Add_Button.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Add_Button.Location = New System.Drawing.Point(195, 274)
        Me.Add_Button.Name = "Add_Button"
        Me.Add_Button.Size = New System.Drawing.Size(58, 36)
        Me.Add_Button.TabIndex = 1
        Me.Add_Button.Text = "+"
        Me.Add_Button.UseVisualStyleBackColor = True
        '
        'Sub_Button
        '
        Me.Sub_Button.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Sub_Button.Location = New System.Drawing.Point(195, 232)
        Me.Sub_Button.Name = "Sub_Button"
        Me.Sub_Button.Size = New System.Drawing.Size(58, 36)
        Me.Sub_Button.TabIndex = 1
        Me.Sub_Button.Text = "-"
        Me.Sub_Button.UseVisualStyleBackColor = True
        '
        'Mul_Button
        '
        Me.Mul_Button.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Mul_Button.Location = New System.Drawing.Point(195, 190)
        Me.Mul_Button.Name = "Mul_Button"
        Me.Mul_Button.Size = New System.Drawing.Size(58, 36)
        Me.Mul_Button.TabIndex = 1
        Me.Mul_Button.Text = "x"
        Me.Mul_Button.UseVisualStyleBackColor = True
        '
        'Button25
        '
        Me.Button25.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button25.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Button25.Location = New System.Drawing.Point(3, 316)
        Me.Button25.Name = "Button25"
        Me.Button25.Size = New System.Drawing.Size(58, 36)
        Me.Button25.TabIndex = 1
        Me.Button25.Text = "."
        Me.Button25.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Button25.UseVisualStyleBackColor = True
        '
        'Button12
        '
        Me.Button12.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button12.Location = New System.Drawing.Point(131, 274)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(58, 36)
        Me.Button12.TabIndex = 1
        Me.Button12.Text = "3"
        Me.Button12.UseVisualStyleBackColor = True
        '
        'Div_Button
        '
        Me.Div_Button.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Div_Button.Location = New System.Drawing.Point(195, 150)
        Me.Div_Button.Name = "Div_Button"
        Me.Div_Button.Size = New System.Drawing.Size(58, 34)
        Me.Div_Button.TabIndex = 1
        Me.Div_Button.Text = "/"
        Me.Div_Button.UseVisualStyleBackColor = True
        '
        'Button38
        '
        Me.Button38.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button38.Location = New System.Drawing.Point(131, 232)
        Me.Button38.Name = "Button38"
        Me.Button38.Size = New System.Drawing.Size(58, 36)
        Me.Button38.TabIndex = 1
        Me.Button38.Text = "6"
        Me.Button38.UseVisualStyleBackColor = True
        '
        'Button24
        '
        Me.Button24.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button24.Location = New System.Drawing.Point(67, 316)
        Me.Button24.Name = "Button24"
        Me.Button24.Size = New System.Drawing.Size(58, 36)
        Me.Button24.TabIndex = 1
        Me.Button24.Text = "0"
        Me.Button24.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button8.Location = New System.Drawing.Point(67, 274)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(58, 36)
        Me.Button8.TabIndex = 1
        Me.Button8.Text = "2"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Button40
        '
        Me.Button40.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button40.Location = New System.Drawing.Point(67, 232)
        Me.Button40.Name = "Button40"
        Me.Button40.Size = New System.Drawing.Size(58, 36)
        Me.Button40.TabIndex = 1
        Me.Button40.Text = "5"
        Me.Button40.UseVisualStyleBackColor = True
        '
        'Button41
        '
        Me.Button41.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button41.Location = New System.Drawing.Point(131, 190)
        Me.Button41.Name = "Button41"
        Me.Button41.Size = New System.Drawing.Size(58, 36)
        Me.Button41.TabIndex = 1
        Me.Button41.Text = "9"
        Me.Button41.UseVisualStyleBackColor = True
        '
        'Button42
        '
        Me.Button42.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button42.Location = New System.Drawing.Point(67, 190)
        Me.Button42.Name = "Button42"
        Me.Button42.Size = New System.Drawing.Size(58, 36)
        Me.Button42.TabIndex = 1
        Me.Button42.Text = "8"
        Me.Button42.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.Location = New System.Drawing.Point(3, 274)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(58, 36)
        Me.Button5.TabIndex = 1
        Me.Button5.Text = "1"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button44
        '
        Me.Button44.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button44.Location = New System.Drawing.Point(3, 232)
        Me.Button44.Name = "Button44"
        Me.Button44.Size = New System.Drawing.Size(58, 36)
        Me.Button44.TabIndex = 1
        Me.Button44.Text = "4"
        Me.Button44.UseVisualStyleBackColor = True
        '
        'Button46
        '
        Me.Button46.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button46.Location = New System.Drawing.Point(3, 190)
        Me.Button46.Name = "Button46"
        Me.Button46.Size = New System.Drawing.Size(58, 36)
        Me.Button46.TabIndex = 1
        Me.Button46.Text = "7"
        Me.Button46.UseVisualStyleBackColor = True
        '
        'Clear_Button
        '
        Me.Clear_Button.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Clear_Button.Location = New System.Drawing.Point(131, 111)
        Me.Clear_Button.Name = "Clear_Button"
        Me.Clear_Button.Size = New System.Drawing.Size(58, 36)
        Me.Clear_Button.TabIndex = 1
        Me.Clear_Button.Text = "C"
        Me.Clear_Button.UseVisualStyleBackColor = True
        '
        'Clear_Entry_Button
        '
        Me.Clear_Entry_Button.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Clear_Entry_Button.Location = New System.Drawing.Point(67, 111)
        Me.Clear_Entry_Button.Name = "Clear_Entry_Button"
        Me.Clear_Entry_Button.Size = New System.Drawing.Size(58, 36)
        Me.Clear_Entry_Button.TabIndex = 1
        Me.Clear_Entry_Button.Text = "CE"
        Me.Clear_Entry_Button.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Panel3)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel3 As Panel
    Friend WithEvents Equ_Label As Label
    Friend WithEvents PLUS_MINUS_Button As Button
    Friend WithEvents Back_Button As Button
    Friend WithEvents Square_Button As Button
    Friend WithEvents Ix_Button As Button
    Friend WithEvents Percent_Button As Button
    Friend WithEvents TextDisplay As TextBox
    Friend WithEvents Equal_Button As Button
    Friend WithEvents Button43 As Button
    Friend WithEvents Add_Button As Button
    Friend WithEvents Sub_Button As Button
    Friend WithEvents Mul_Button As Button
    Friend WithEvents Button25 As Button
    Friend WithEvents Button12 As Button
    Friend WithEvents Div_Button As Button
    Friend WithEvents Button38 As Button
    Friend WithEvents Button24 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents Button40 As Button
    Friend WithEvents Button41 As Button
    Friend WithEvents Button42 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button44 As Button
    Friend WithEvents Button46 As Button
    Friend WithEvents Clear_Button As Button
    Friend WithEvents Clear_Entry_Button As Button
End Class
