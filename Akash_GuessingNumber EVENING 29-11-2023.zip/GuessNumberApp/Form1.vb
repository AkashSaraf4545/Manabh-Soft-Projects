﻿Public Class Form1
    Dim your_guessed_number, system_number, remaining_attempts, random_number As Int32
    Dim flag As Boolean = False
    Dim rand As New Random()

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles BtnQuit.Click
        Close()
    End Sub



    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TxtMsg.TextChanged
        If flag = True Then
            system_number = Int(Rnd() * 8) + 1
            remaining_attempts = 3
            txtAttempts_Remaining.Text = remaining_attempts.ToString()
        End If
    End Sub

    Private Sub TextBox1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtMsg.KeyPress
        If Char.IsDigit(e.KeyChar) Then
            TxtMsg.Clear()
            If TxtMsg.Text = "" Then


                TxtMsg.Text &= e.KeyChar.ToString()
                e.Handled = True
                TxtMsg.Select(TxtMsg.TextLength, TxtMsg.TextLength)
            End If

        End If


        If remaining_attempts > 0 Then
            If e.KeyChar = ChrW(Keys.Enter) Then
                your_guessed_number = TxtMsg.Text
                TxtMsg.Clear()
                e.Handled = True
                If your_guessed_number = system_number Then
                    TxtMsg.Clear()
                    TxtMsg.Text = "CONGRATS YOU WON!!!"
                    TxtMsg.Focus()
                    TxtMsg.Select(TxtMsg.TextLength, TxtMsg.TextLength)
                    flag = True
                ElseIf your_guessed_number > system_number Then
                    TxtMsg.Clear()
                    TxtMsg.Text = "WRONG GUESS, TRY LOWER NUMBER!"
                    remaining_attempts -= 1
                    txtAttempts_Remaining.Text = remaining_attempts.ToString
                    TxtMsg.Focus()
                    TxtMsg.Select(TxtMsg.TextLength, TxtMsg.TextLength)
                    flag = False
                ElseIf your_guessed_number < system_number Then
                    TxtMsg.Clear()
                    TxtMsg.Text = "WRONG GUESS, TRY HIGER NUMBER!"
                    remaining_attempts -= 1
                    txtAttempts_Remaining.Text = remaining_attempts.ToString
                    TxtMsg.Focus()
                    TxtMsg.Select(TxtMsg.TextLength, TxtMsg.TextLength)
                    flag = False
                End If
            End If
        End If

        If e.KeyChar > "10" AndAlso e.KeyChar < "1" Then
            TxtMsg.Text = "INVALID NUMBER, PLEASE ENTER A NUMBER BETWEEN 1 AND 10"
            TxtMsg.Select(TxtMsg.TextLength, TxtMsg.TextLength)
        End If

        If e.KeyChar = ChrW(Keys.Enter) AndAlso remaining_attempts < 1 Then
            TxtMsg.Text = "BETTER LUCK NEXT TIME :( " & vbCrLf & " The number was " & system_number
            flag = True
            TxtMsg.Select(TxtMsg.TextLength, TxtMsg.TextLength)
        End If
    End Sub

    Private Sub BtnRetry_Click(sender As Object, e As EventArgs) Handles BtnRetry.Click
        Application.Restart()
    End Sub

    Private Sub BtnResetChance_Click(sender As Object, e As EventArgs) Handles BtnResetChance.Click
        flag = True
        TxtMsg.Clear()
        TxtMsg.Text = "PLEASE ENTER A NUMBER BETWEEN 1 AND 10"
        TxtMsg.Focus()
        TxtMsg.Select(TxtMsg.TextLength, TxtMsg.TextLength)
    End Sub





    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles BtnEnter.Click
        your_guessed_number = TxtMsg.Text
        TxtMsg.Clear()

        If your_guessed_number = system_number Then
            TxtMsg.Clear()
            TxtMsg.Text = "CONGRATS YOU WON!!!"
            TxtMsg.Focus()
            TxtMsg.Select(TxtMsg.TextLength, TxtMsg.TextLength)
            flag = True
        ElseIf your_guessed_number > system_number Then
            TxtMsg.Clear()
            TxtMsg.Text = "WRONG GUESS, TRY LOWER NUMBER!"
            remaining_attempts -= 1
            txtAttempts_Remaining.Text = remaining_attempts.ToString()
            TxtMsg.Focus()
            TxtMsg.Select(TxtMsg.TextLength, TxtMsg.TextLength)
            flag = False
        ElseIf your_guessed_number < system_number Then
            TxtMsg.Clear()
            TxtMsg.Text = "WRONG GUESS, TRY HIGER NUMBER!"
            remaining_attempts -= 1
            txtAttempts_Remaining.Text = remaining_attempts.ToString()
            TxtMsg.Focus()
            TxtMsg.Select(TxtMsg.TextLength, TxtMsg.TextLength)
            flag = False
        End If
        If remaining_attempts < 1 Then
            TxtMsg.Text = "BETTER LUCK NEXT TIME :( " & vbCrLf & " The number was " & system_number
            flag = True
            TxtMsg.Select(TxtMsg.TextLength, TxtMsg.TextLength)
        End If
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        remaining_attempts = 3
        flag = True
        If flag = True Then
            system_number = Int(Rnd() * 8) + 1
            remaining_attempts = 3
            txtAttempts_Remaining.Text = remaining_attempts.ToString()
        End If

    End Sub

    Private Sub txtAnswer_TextChanged(sender As Object, e As EventArgs) Handles txtAnswer.TextChanged
        txtAnswer.Text = system_number.ToString()
    End Sub


    Private Sub Attempts_Remaining_TextChanged(sender As Object, e As EventArgs) Handles txtAttempts_Remaining.TextChanged
    End Sub
End Class




