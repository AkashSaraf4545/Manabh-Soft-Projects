﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.txtAnswer = New System.Windows.Forms.TextBox()
        Me.BtnResetChance = New System.Windows.Forms.Button()
        Me.BtnRetry = New System.Windows.Forms.Button()
        Me.Attempt_Label = New System.Windows.Forms.Label()
        Me.txtAttempts_Remaining = New System.Windows.Forms.TextBox()
        Me.labelPlay = New System.Windows.Forms.Label()
        Me.BtnEnter = New System.Windows.Forms.Button()
        Me.BtnQuit = New System.Windows.Forms.Button()
        Me.TxtMsg = New System.Windows.Forms.TextBox()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Panel1.Controls.Add(Me.txtAnswer)
        Me.Panel1.Controls.Add(Me.BtnResetChance)
        Me.Panel1.Controls.Add(Me.BtnRetry)
        Me.Panel1.Controls.Add(Me.Attempt_Label)
        Me.Panel1.Controls.Add(Me.txtAttempts_Remaining)
        Me.Panel1.Controls.Add(Me.labelPlay)
        Me.Panel1.Controls.Add(Me.BtnEnter)
        Me.Panel1.Controls.Add(Me.BtnQuit)
        Me.Panel1.Controls.Add(Me.TxtMsg)
        Me.Panel1.Location = New System.Drawing.Point(12, 12)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(209, 328)
        Me.Panel1.TabIndex = 0
        '
        'txtAnswer
        '
        Me.txtAnswer.Font = New System.Drawing.Font("Times New Roman", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAnswer.Location = New System.Drawing.Point(131, 292)
        Me.txtAnswer.Name = "txtAnswer"
        Me.txtAnswer.Size = New System.Drawing.Size(47, 29)
        Me.txtAnswer.TabIndex = 8
        '
        'BtnResetChance
        '
        Me.BtnResetChance.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.BtnResetChance.Font = New System.Drawing.Font("Times New Roman", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnResetChance.Location = New System.Drawing.Point(103, 179)
        Me.BtnResetChance.Name = "BtnResetChance"
        Me.BtnResetChance.Size = New System.Drawing.Size(75, 35)
        Me.BtnResetChance.TabIndex = 7
        Me.BtnResetChance.Text = "Reset"
        Me.BtnResetChance.UseVisualStyleBackColor = False
        '
        'BtnRetry
        '
        Me.BtnRetry.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.BtnRetry.Font = New System.Drawing.Font("Times New Roman", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnRetry.Location = New System.Drawing.Point(26, 179)
        Me.BtnRetry.Name = "BtnRetry"
        Me.BtnRetry.Size = New System.Drawing.Size(75, 35)
        Me.BtnRetry.TabIndex = 6
        Me.BtnRetry.Text = "Retry"
        Me.BtnRetry.UseVisualStyleBackColor = False
        '
        'Attempt_Label
        '
        Me.Attempt_Label.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Attempt_Label.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Attempt_Label.ForeColor = System.Drawing.SystemColors.MenuText
        Me.Attempt_Label.Location = New System.Drawing.Point(22, 242)
        Me.Attempt_Label.Name = "Attempt_Label"
        Me.Attempt_Label.Size = New System.Drawing.Size(103, 44)
        Me.Attempt_Label.TabIndex = 5
        Me.Attempt_Label.Text = "Attempts Remaining"
        Me.Attempt_Label.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'txtAttempts_Remaining
        '
        Me.txtAttempts_Remaining.Font = New System.Drawing.Font("Times New Roman", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAttempts_Remaining.Location = New System.Drawing.Point(131, 242)
        Me.txtAttempts_Remaining.Multiline = True
        Me.txtAttempts_Remaining.Name = "txtAttempts_Remaining"
        Me.txtAttempts_Remaining.Size = New System.Drawing.Size(47, 44)
        Me.txtAttempts_Remaining.TabIndex = 4
        Me.txtAttempts_Remaining.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'labelPlay
        '
        Me.labelPlay.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.labelPlay.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labelPlay.ForeColor = System.Drawing.SystemColors.MenuText
        Me.labelPlay.Location = New System.Drawing.Point(22, 15)
        Me.labelPlay.Name = "labelPlay"
        Me.labelPlay.Size = New System.Drawing.Size(156, 23)
        Me.labelPlay.TabIndex = 3
        Me.labelPlay.Text = "PLAY"
        Me.labelPlay.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'BtnEnter
        '
        Me.BtnEnter.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.BtnEnter.Font = New System.Drawing.Font("Times New Roman", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnEnter.Location = New System.Drawing.Point(103, 138)
        Me.BtnEnter.Name = "BtnEnter"
        Me.BtnEnter.Size = New System.Drawing.Size(75, 35)
        Me.BtnEnter.TabIndex = 2
        Me.BtnEnter.Text = "Enter"
        Me.BtnEnter.UseVisualStyleBackColor = False
        '
        'BtnQuit
        '
        Me.BtnQuit.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.BtnQuit.Font = New System.Drawing.Font("Times New Roman", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnQuit.Location = New System.Drawing.Point(22, 138)
        Me.BtnQuit.Name = "BtnQuit"
        Me.BtnQuit.Size = New System.Drawing.Size(75, 35)
        Me.BtnQuit.TabIndex = 1
        Me.BtnQuit.Text = "Quit"
        Me.BtnQuit.UseVisualStyleBackColor = False
        '
        'TxtMsg
        '
        Me.TxtMsg.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtMsg.Location = New System.Drawing.Point(22, 56)
        Me.TxtMsg.Multiline = True
        Me.TxtMsg.Name = "TxtMsg"
        Me.TxtMsg.Size = New System.Drawing.Size(156, 76)
        Me.TxtMsg.TabIndex = 0
        Me.TxtMsg.Text = "PLEASE ENTER A NUMBER BETWEEN 1 AND 10"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSize = True
        Me.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Panel1)
        Me.KeyPreview = True
        Me.Name = "Form1"
        Me.Padding = New System.Windows.Forms.Padding(10, 0, 10, 10)
        Me.Text = "Guessing a Number"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents BtnEnter As Button
    Friend WithEvents BtnQuit As Button
    Friend WithEvents TxtMsg As TextBox
    Friend WithEvents labelPlay As Label
    Friend WithEvents Attempt_Label As Label
    Friend WithEvents txtAttempts_Remaining As TextBox
    Friend WithEvents BtnRetry As Button
    Friend WithEvents BtnResetChance As Button
    Friend WithEvents txtAnswer As TextBox
End Class
